<html>
    <head>
        <title>Start Sahayog</title>
    </head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="../styles/login.css">


    <head>
        <!-- Site made with Mobirise AI Website Builder v0.01, https://ai.mobirise.com -->
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="generator" content="Mobirise AI v0.01, ai.mobirise.com">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
        <link rel="shortcut icon" href="assets/images/logo5.png" type="image/x-icon">
        <meta name="description" content="Tackling Nepal's mental health crisis with specialist mentor booking, emergency contact, blog, and support chat. Tailored navigation and 24/7 crisis support combat barriers and taboos.">

        <title>Nepal Mental Health</title>
        <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
        <link rel="stylesheet" href="assets/parallax/jarallax.css">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
        <link rel="stylesheet" href="assets/dropdown/css/style.css">
        <link rel="stylesheet" href="assets/socicon/css/styles.css">
        <link rel="stylesheet" href="assets/animatecss/animate.css">
        <link rel="stylesheet" href="assets/theme/css/style.css">
        <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;700&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
        <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;700&display=swap"></noscript>
        <link rel="preload" as="style" href="assets/mobirise/css/additional.css"><link rel="stylesheet" href="assets/mobirise/css/additional.css" type="text/css">
        <style>:root{ --background: #FFF0F0; --dominant-color: #FF6B6B; --primary-color: #4ECDC4; --secondary-color: #FBE693; --success-color: #24C47A; --danger-color: #C62232; --warning-color: #E8AE00; --info-color: #0CB9DC; --background-text: #000000; --dominant-text: #000000; --primary-text: #000000; --secondary-text: #000000; --success-text: #000000; --danger-text: #FFFFFF; --warning-text: #000000; --info-text: #FFFFFF;}</style>
    </head>
    <body class="text-center">
    
    <?php
    session_start();
    ?>
    </div>